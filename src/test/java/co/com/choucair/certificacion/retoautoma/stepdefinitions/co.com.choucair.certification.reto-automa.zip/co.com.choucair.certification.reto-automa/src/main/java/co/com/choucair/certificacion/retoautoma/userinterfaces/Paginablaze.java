package co.com.choucair.certificacion.retoautoma.userinterfaces;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.support.FindBy;

@DefaultUrl("https://www.demoblaze.com/")
public class Paginablaze extends PageObject{
}

